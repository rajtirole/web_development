# Backend project Proffessional way of code structure


## files and folder
Project >
1. server>
1. package
2. Readme.md
3. gitignore
4. use nodemon for save change 
5. .prettierrc 

npm i -D nodemon

## folders
controller
db or config
middlewares
models
routes
utils



2.
## TOOls
1. git ignore generators
## packages
dev dependencies
nodemon
prettier
## steps
mongoose atlas and database create
