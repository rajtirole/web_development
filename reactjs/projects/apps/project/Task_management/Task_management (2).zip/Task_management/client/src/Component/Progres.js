import React from 'react'
import ProgresStyle from './ProgresStyle.css'
import Collap1 from './image/collap.png'

export default function () {
  return (
    <div  className='progres'>
      <h5 className='heading4'>  in progres</h5>
      <div className='collap4'> <img src={Collap1}/></div>
    </div>
  )
}
