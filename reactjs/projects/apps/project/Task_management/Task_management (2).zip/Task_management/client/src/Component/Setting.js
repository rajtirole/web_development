import React from 'react'
import Data from './Settingstyle/Setting'
import data1 from './Settingstyle/Settingstyle.css'
export default function Setting() {
  return (
   <>
  <Data></Data>
   </>
  )
}
