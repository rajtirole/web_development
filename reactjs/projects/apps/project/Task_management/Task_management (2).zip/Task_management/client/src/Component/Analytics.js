import React from 'react'
import Analyticss from './Analyticsstyle/Analytics'
import Analytics1 from './Analyticsstyle/Analyticsstyle.css'

export default function Analytics() {
  return (
    <>
      <Analyticss></Analyticss>
    
    </>
  )
}
