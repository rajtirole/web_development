import React from 'react'
import BoardStyle from './BoardStyle.css'
import Backlog from './Backlog'
import Todo from './Todo'
import Progres from './Progres'
import Done from './Done'
import Dashboard from './Dashboard'
export default function Board() {
  return (
    <>
  <Dashboard></Dashboard>
    <div className='Board'>
       <h2> Board </ h2>
       <div  className='herosection'>
       <Backlog/>
       <Todo/>
       <Progres/>
       <Done/>
       </div>
    </div>
    </>
  )
}

