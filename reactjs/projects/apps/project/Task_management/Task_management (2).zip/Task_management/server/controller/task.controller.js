import { config } from "dotenv";
config();
import AppError from "../utils/error.utils.js";
import Usertaskmodel from "../model/usertask.model.js";

async function backlogtask(req,res,next){

   try {
   
    const{taskTittle,priority,date,checklist}=req.body;
    if (!taskTittle) {

        return next(
          new AppError("All fields are required", 400)
        );
      }
    console.log(taskTittle,priority,date,checklist);
    const id = req.user.id;
    console.log(id);
    const user = await Usertaskmodel.findOne({userid:id})
    console.log(user);
    if(!user){
        const usertask=Usertaskmodel.create({
            userid:id,
            backlog:{
                backlogtask:[{taskTittle,priority,date,checklist}]
            }
        })
        res.status(200).json({
            success: true,
            message: "backlog task create succesfully",
            user,
          });
    }
    // res.cookie("token", token, cookieOptions);
    let backlogtaskarr= user.backlog.backlogtask
    console.log('backlogarr',backlogtaskarr);
    user.backlog.backlogtask=[...backlogtaskarr,{taskTittle,priority,date,checklist}]
    console.log( 'user backlogtask',user.backlog.backlogtask);
    await user.save();
    res.status(200).json({
        success: true,
        message: "backlog task updated succesfully",
       
      });
   } catch (error) {
    console.log(error);
    
   }

}
async function todotask(req,res,next){

   try {
   
    const{taskTittle,priority,date,checklist}=req.body;
    if (!taskTittle) {

        return next(
          new AppError("All fields are required", 400)
        );
      }
    console.log(taskTittle,priority,date,checklist);
    const id = req.user.id;
    console.log(id);
    const user = await Usertaskmodel.findOne({userid:id})
    console.log(user);
    if(!user){
        const usertask=Usertaskmodel.create({
            userid:id,
            todo:{
                todotask:[{taskTittle,priority,date,checklist}]
            }
        })
        res.status(200).json({
            success: true,
            message: "todo task create succesfully",
            user,
          });
    }
    // res.cookie("token", token, cookieOptions);
    let todotaskarr= user.todo.todotask
    console.log('todotaskarr',todotaskarr);
    user.todo.todotask=[...todotaskarr,{taskTittle,priority,date,checklist}]
    console.log( 'user todotaskarr',user.todo.todotask);
    await user.save();
    res.status(200).json({
        success: true,
        message: "todo task updated succesfully",
       
      });
   } catch (error) {
    console.log(error);
    
   }

}
export {backlogtask,todotask}